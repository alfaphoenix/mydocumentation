---
tags: [golang, documentation, moc, index]
aliases: [Go Documentation Index, Go Map of Content]
---

# 📚 Go (Golang) — Карта Содержания (MOC)

Это центральный индексный файл для всей документации по Go, структурированный для удобной навигации в Obsidian.

## 1. Основы Языка (Basics)

Основные строительные блоки языка Go.

*   [[01_Basics/01_Hello_World_and_Packages|Hello World и Пакеты]]
*   [[01_Basics/02_Variables_and_Types|Переменные, Типы и Константы]]
*   [[01_Basics/03_Control_Flow|Управляющие Конструкции (if, for, switch)]]
*   [[01_Basics/04_Functions|Функции, Замыкания и defer]]

## 2. Структуры Данных (Data Structures)

Встроенные типы данных для хранения коллекций.

*   [[02_Data_Structures/01_Arrays_and_Slices|Массивы и Срезы (Slices)]]
*   [[02_Data_Structures/02_Maps|Карты (Maps)]]
*   [[02_Data_Structures/03_Structs|Структуры (Structs) и Встраивание]]

## 3. Методы и Интерфейсы (Methods and Interfaces)

Объектно-ориентированные концепции Go.

*   [[03_Methods_and_Interfaces/01_Methods|Методы и Ресиверы]]
*   [[03_Methods_and_Interfaces/02_Interfaces|Интерфейсы и Полиморфизм]]

## 4. Параллелизм (Concurrency)

Модель параллелизма Go, основанная на CSP.

*   [[04_Concurrency/01_Goroutines|Горутины (Goroutines) и sync.WaitGroup]]
*   [[04_Concurrency/02_Channels|Каналы (Channels) и их типы]]
*   [[04_Concurrency/03_Select|Оператор select и таймауты]]

## 5. Продвинутые Темы (Advanced Topics)

Сложные и современные возможности языка.

*   [[05_Advanced_Topics/01_Error_Handling|Обработка Ошибок, panic и recover]]
*   [[05_Advanced_Topics/02_Pointers|Указатели (Pointers)]]
*   [[05_Advanced_Topics/03_Generics|Дженерики (Generics)]]

## 6. Стандартная Библиотека (Standard Library)

Обзор наиболее важных встроенных пакетов.

*   [[06_Standard_Library/01_Standard_Library_Overview|Обзор Стандартной Библиотеки]]
*   [[06_Standard_Library/02_Context|Пакет context (Управление отменой и таймаутами)]]

---
*Документация сгенерирована Manus AI.*
