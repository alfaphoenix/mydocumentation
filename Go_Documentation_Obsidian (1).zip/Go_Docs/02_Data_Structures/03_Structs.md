---
tags: [golang, data-structures, struct, embedding]
aliases: [Go Структуры, Go Встраивание]
---

# 🧱 Структуры (Structs)

Структура — это коллекция полей. Она используется для группировки данных для формирования более сложных записей.

## 1. Объявление и Инициализация

### Объявление

```go
type Vertex struct {
	X int
	Y int
}

// Можно объявить поля одного типа в одной строке
type Point struct {
	X, Y float64
}
```

### Инициализация

```go
// 1. Инициализация полей по порядку
p1 := Vertex{1, 2}

// 2. Инициализация полей по имени (рекомендуется)
p2 := Vertex{X: 10, Y: 20}

// 3. Инициализация с нулевыми значениями
p3 := Vertex{} // X=0, Y=0

// 4. Указатель на структуру
p4 := &Vertex{1, 2}
```

## 2. Доступ к Полям

Доступ к полям осуществляется через оператор точки (`.`).

```go
p := Vertex{1, 2}
p.X = 4 // Изменение значения
fmt.Println(p.X) // 4

// Доступ через указатель
ptr := &p
ptr.X = 1e9 // Go автоматически разыменовывает указатель: (*ptr).X = 1e9
fmt.Println(p.X) // 1000000000
```

## 3. Встраивание (Embedding)

Go не имеет наследования, но использует **встраивание** для достижения композиции. Встраивание структуры в другую структуру позволяет "наследовать" ее поля и методы.

```go
type Person struct {
	Name string
	Age  int
}

type Employee struct {
	Person // Встраивание Person (анонимное поле)
	Salary float64
}

func main() {
	e := Employee{
		Person: Person{Name: "Alice", Age: 30},
		Salary: 50000,
	}
	// Доступ к полю Name напрямую через Employee
	fmt.Println(e.Name) // Alice
	// Эквивалентно:
	fmt.Println(e.Person.Name) // Alice
}
```

## 4. Теги Структур (Struct Tags)

Теги используются для предоставления метаданных полям структуры, часто для кодирования/декодирования в форматы, такие как JSON, XML или для ORM.

```go
type User struct {
	ID       int    `json:"id"`
	Username string `json:"username"`
	Email    string `json:"-"` // Поле будет пропущено при кодировании в JSON
}

// Пример использования с пакетом encoding/json
func main() {
	u := User{ID: 1, Username: "gopher", Email: "gopher@go.dev"}
	b, _ := json.Marshal(u)
	fmt.Println(string(b)) // {"id":1,"username":"gopher"}
}
```
