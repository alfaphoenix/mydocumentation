---
tags: [golang, standard-library, context, concurrency]
aliases: [Go Context, Go Контекст]
---

# 📜 Пакет `context`

Пакет `context` предоставляет способ передачи данных, таймаутов и сигналов отмены между API-границами и горутинами.

## 1. Назначение

`context.Context` используется для:

1.  **Отмены (Cancellation):** Предоставление сигнала отмены для связанных горутин.
2.  **Таймаута (Timeout):** Автоматическая отмена операции по истечении времени.
3.  **Дедлайна (Deadline):** Автоматическая отмена операции к определенному моменту времени.
4.  **Передачи Значений (Value Passing):** Передача запросо-специфичных значений (например, ID запроса, данные аутентификации).

## 2. Основные Функции

| Функция | Описание |
| :--- | :--- |
| `context.Background()` | Возвращает пустой контекст. Используется как корневой контекст. |
| `context.TODO()` | Возвращает пустой контекст. Используется, когда неясно, какой контекст использовать. |
| `context.WithCancel(parent)` | Возвращает новый контекст и функцию `cancel`. Вызов `cancel` отменяет контекст. |
| `context.WithTimeout(parent, duration)` | Возвращает контекст, который автоматически отменяется по истечении `duration`. |
| `context.WithDeadline(parent, time)` | Возвращает контекст, который автоматически отменяется к указанному времени. |
| `context.WithValue(parent, key, val)` | Возвращает контекст с прикрепленным значением. |

## 3. Пример Использования с Таймаутом

```go
func longRunningTask(ctx context.Context) (string, error) {
	select {
	case <-time.After(5 * time.Second):
		// Имитация долгой работы
		return "Task completed successfully", nil
	case <-ctx.Done():
		// Контекст был отменен (например, из-за таймаута)
		return "", ctx.Err()
	}
}

func main() {
	// Создаем контекст с таймаутом 3 секунды
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel() // Всегда вызывайте cancel, чтобы освободить ресурсы

	result, err := longRunningTask(ctx)

	if err != nil {
		fmt.Println("Error:", err) // Error: context deadline exceeded
	} else {
		fmt.Println("Result:", result)
	}
}
```

## 4. Правила Использования

1.  **Первый Аргумент:** Контекст всегда должен быть первым аргументом функции.
2.  **Не Хранить:** Не храните контекст в структурах. Передавайте его явно.
3.  **Корневой Контекст:** Используйте `Background` или `TODO` для создания корневого контекста.
4.  **Отмена:** Всегда вызывайте функцию `cancel` для контекстов, созданных с `WithCancel`, `WithTimeout` или `WithDeadline`, чтобы избежать утечек горутин.
