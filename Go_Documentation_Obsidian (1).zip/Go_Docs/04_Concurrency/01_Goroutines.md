---
tags: [golang, concurrency, goroutine]
aliases: [Go Горутины, Go Параллелизм]
---

# 🏃 Горутины (Goroutines)

Горутины — это легковесные потоки, управляемые средой выполнения Go. Они являются ключевым элементом модели параллелизма Go.

## 1. Запуск Горутины

Для запуска функции в новой горутине используется ключевое слово `go`.

```go
func f(from string) {
	for i := 0; i < 3; i++ {
		fmt.Println(from, ":", i)
	}
}

func main() {
	f("direct") // Выполняется синхронно

	go f("goroutine") // Выполняется асинхронно в новой горутине

	// Запуск анонимной функции в горутине
	go func(msg string) {
		fmt.Println(msg)
	}("going")

	// Главная горутина должна подождать, пока другие горутины завершатся.
	// В реальном коде используйте sync.WaitGroup или каналы.
	time.Sleep(time.Second)
	fmt.Println("done")
}
```

## 2. Модель Параллелизма Go

Go использует модель **CSP (Communicating Sequential Processes)**, которая фокусируется на передаче данных между независимыми процессами (горутинами) через каналы.

> **Идиома Go:** Не передавайте данные по общей памяти; вместо этого **передавайте память по каналам**.

## 3. `sync.WaitGroup`

`sync.WaitGroup` используется для ожидания завершения набора горутин.

| Метод | Описание |
| :--- | :--- |
| `Add(delta int)` | Увеличивает счетчик. |
| `Done()` | Уменьшает счетчик на 1 (обычно вызывается через `defer`). |
| `Wait()` | Блокирует до тех пор, пока счетчик не станет 0. |

```go
func worker(id int, wg *sync.WaitGroup) {
	defer wg.Done() // Уменьшает счетчик при выходе
	fmt.Printf("Worker %d starting\n", id)
	time.Sleep(time.Second)
	fmt.Printf("Worker %d finished\n", id)
}

func main() {
	var wg sync.WaitGroup

	for i := 1; i <= 5; i++ {
		wg.Add(1) // Увеличиваем счетчик
		go worker(i, &wg)
	}

	wg.Wait() // Ждем завершения всех горутин
	fmt.Println("All workers finished")
}
```
