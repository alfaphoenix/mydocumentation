---
tags: [golang, concurrency, select]
aliases: [Go Select, Go Мультиплексирование]
---

# 🔀 `select`

Оператор `select` позволяет горутине ждать операций на нескольких каналах. Он блокируется до тех пор, пока один из `case` не сможет быть выполнен.

## 1. Базовый `select`

```go
select {
case v := <-ch1:
	// Получено значение из ch1
case v := <-ch2:
	// Получено значение из ch2
default:
	// Ни один канал не готов (неблокирующая операция)
}
```

### Правила Выполнения

1.  **Готовность:** `select` ждет, пока один из каналов не будет готов к отправке или получению.
2.  **Случайный Выбор:** Если готовы несколько каналов, `select` выбирает один из них **случайным образом**.
3.  **Блокировка:** Если ни один канал не готов и нет `default`, `select` **блокируется** до тех пор, пока один из каналов не станет готов.

## 2. Таймауты

`select` часто используется для реализации таймаутов, используя канал, возвращаемый `time.After`.

```go
func main() {
	ch := make(chan string)
	go func() {
		time.Sleep(2 * time.Second)
		ch <- "result"
	}()

	select {
	case res := <-ch:
		fmt.Println(res)
	case <-time.After(1 * time.Second):
		fmt.Println("timeout") // Выполнится, так как 1 секунда < 2 секунды
	}
}
```

## 3. Неблокирующий `select`

Использование `default` делает `select` неблокирующим.

```go
select {
case msg := <-messages:
	fmt.Println("received message", msg)
default:
	fmt.Println("no message received") // Выполнится немедленно, если канал пуст
}
```

## 4. `select` и Закрытие Канала

Если закрытый канал готов к получению, `case` будет выполнен, и будет возвращено нулевое значение типа канала с `ok=false`.

```go
ch := make(chan int)
close(ch)

select {
case v, ok := <-ch:
	if !ok {
		fmt.Println("channel closed") // Выполнится
	}
	// ...
}
```
