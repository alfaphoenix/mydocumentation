---
tags: [golang, interfaces, polymorphism]
aliases: [Go Интерфейсы, Go Полиморфизм]
---

# 🔗 Интерфейсы

Интерфейсы в Go — это мощный механизм для достижения полиморфизма.

## 1. Что Такое Интерфейс

Интерфейс — это набор сигнатур методов. Тип **неявно** реализует интерфейс, если он реализует все методы, объявленные в этом интерфейсе.

```go
// Интерфейс Abser определяет один метод: Abs()
type Abser interface {
	Abs() float64
}

type MyFloat float64
type Vertex struct { X, Y float64 }

// MyFloat реализует Abser
func (f MyFloat) Abs() float64 {
	if f < 0 {
		return float64(-f)
	}
	return float64(f)
}

// *Vertex реализует Abser
func (v *Vertex) Abs() float64 {
	return math.Sqrt(v.X*v.X + v.Y*v.Y)
}

func main() {
	var a Abser // Переменная типа интерфейса
	
	f := MyFloat(-math.Sqrt2)
	v := Vertex{3, 4}
	
	a = f    // OK: MyFloat реализует Abser
	a = &v   // OK: *Vertex реализует Abser
	
	fmt.Println(a.Abs())
}
```

## 2. Пустой Интерфейс (`interface{}` или `any`)

Пустой интерфейс (`interface{}`) или его современный псевдоним (`any`) может содержать значение **любого типа**.

```go
var i interface{}
i = 42
i = "hello"
```

## 3. Утверждение Типа (Type Assertion)

Утверждение типа используется для извлечения базового значения из переменной интерфейса.

```go
var i interface{} = "hello"

// Утверждение, что i содержит string
s := i.(string)
fmt.Println(s) // hello

// "Защищенное" утверждение с проверкой
s, ok := i.(string)
if ok {
	fmt.Println("i is a string:", s)
}

// Если утверждение неверно, произойдет паника
// f := i.(float64) // Паника!
```

## 4. Переключатель Типа (Type Switch)

Используется для определения типа значения, хранящегося в интерфейсе.

```go
func do(i interface{}) {
	switch v := i.(type) {
	case int:
		fmt.Printf("Удвоенное %v это %v\n", v, v*2)
	case string:
		fmt.Printf("%q имеет длину %v байт\n", v, len(v))
	default:
		fmt.Printf("Неизвестный тип %T!\n", v)
	}
}
```

## 5. Интерфейс `error`

Интерфейс `error` — это один из самых важных интерфейсов в Go.

```go
type error interface {
	Error() string
}
```

Любой тип, реализующий метод `Error() string`, может быть использован как значение ошибки.
