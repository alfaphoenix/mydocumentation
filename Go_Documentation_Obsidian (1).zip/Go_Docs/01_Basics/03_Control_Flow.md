---
tags: [golang, basics, control-flow, if, for, switch]
aliases: [Go Управляющие Конструкции, Go Циклы]
---

# 🚦 Управляющие Конструкции

## 1. Условный Оператор `if`

В Go не используются скобки вокруг условия, но обязательны фигурные скобки вокруг тела.

### Базовый `if`

```go
if x > 0 {
	fmt.Println("Положительное число")
} else if x < 0 {
	fmt.Println("Отрицательное число")
} else {
	fmt.Println("Ноль")
}
```

### `if` с Короткой Инструкцией

`if` может начинаться с короткой инструкции, которая выполняется перед условием. Переменные, объявленные в этой инструкции, доступны только внутри блока `if` и `else`.

```go
// Короткая инструкция объявляет 'v'
if v := math.Pow(x, n); v < limit {
	fmt.Println(v)
} else {
	fmt.Println(limit)
}
// Переменная 'v' здесь недоступна
```

## 2. Цикл `for`

В Go есть только один цикл — `for`. Он может использоваться в трех формах.

### Полная Форма

Эквивалент цикла `for` в C, C++ или Java.

```go
for init; condition; post {
	// ...
}

// Пример:
for i := 0; i < 10; i++ {
	fmt.Println(i)
}
```

### Форма `while`

Опуская `init` и `post` инструкции, `for` работает как цикл `while`.

```go
sum := 1
for sum < 1000 { // Только условие
	sum += sum
}
fmt.Println(sum)
```

### Бесконечный Цикл

Опуская все части, создается бесконечный цикл.

```go
for {
	// Бесконечный цикл
}
```

### Цикл `for range`

Используется для итерации по массивам, срезам, строкам, картам и каналам.

```go
// Итерация по срезу
nums := []int{1, 2, 3}
for index, value := range nums {
	fmt.Printf("Индекс: %d, Значение: %d\n", index, value)
}

// Итерация по карте
kvs := map[string]string{"a": "apple", "b": "banana"}
for k, v := range kvs {
	fmt.Printf("%s -> %s\n", k, v)
}

// Если нужен только индекс/ключ
for i := range nums {
	// ...
}

// Если нужно только значение
for _, v := range nums {
	// ...
}
```

## 3. Оператор `switch`

Оператор `switch` в Go более гибкий, чем в других языках.

### Автоматический `break`

В Go `case` автоматически прерывается (`break`), если не используется ключевое слово `fallthrough`.

```go
switch os := runtime.GOOS; os {
case "darwin":
	fmt.Println("macOS.")
case "linux":
	fmt.Println("Linux.")
default: // Выполняется, если ни один case не совпал
	fmt.Printf("%s.\n", os)
}
```

### `switch` без Условия

Может использоваться как более чистый способ записи длинной цепочки `if-else if-else`.

```go
t := time.Now()
switch {
case t.Hour() < 12:
	fmt.Println("Утро")
case t.Hour() < 17:
	fmt.Println("День")
default:
	fmt.Println("Вечер")
}
```

### `fallthrough`

Ключевое слово `fallthrough` заставляет выполнение переходить к следующему `case`.

```go
switch i {
case 0:
case 1:
	fmt.Println("1 или 0")
	fallthrough // Переход к следующему case
case 2:
	fmt.Println("2 или 1 или 0")
}
```
